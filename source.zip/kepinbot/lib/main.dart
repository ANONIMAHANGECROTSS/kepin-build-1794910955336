import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const KepinBotApp());

const Color kAccent = Color(0xFF22D3EE);
const Color kAccent2 = Color(0xFF818CF8);
const Color kBg = Color(0xFF05060A);

class KepinBotApp extends StatelessWidget {
  const KepinBotApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KEPINBOTSTARTER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(
          primary: kAccent,
          secondary: kAccent2,
        ),
      ),
      home: const BootScreen(),
    );
  }
}

/* ================= BOOT: cek apakah pernah jalanin bot ================= */
class BootScreen extends StatefulWidget {
  const BootScreen({super.key});
  @override
  State<BootScreen> createState() => _BootScreenState();
}

class _BootScreenState extends State<BootScreen> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final sp = await SharedPreferences.getInstance();
    final token = sp.getString('bot_token');
    final program = sp.getString('bot_program');
    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    if (token != null && token.isNotEmpty && program != null) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => RunnerScreen(token: token, program: program)),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const SetupScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 46, height: 46,
              child: CircularProgressIndicator(strokeWidth: 3, color: kAccent),
            ),
            SizedBox(height: 18),
            Text('KEPINBOTSTARTER', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
            SizedBox(height: 6),
            Text('by Kevin', style: TextStyle(fontSize: 11, color: Colors.white38)),
          ],
        ),
      ),
    );
  }
}

/* ================= SETUP: input token + validasi getMe ================= */
class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _tokenCtrl = TextEditingController();
  final _progCtrl = TextEditingController();
  bool _loading = false;
  String? _err;
  Map<String, dynamic>? _botInfo;

  Future<void> _validate() async {
    final token = _tokenCtrl.text.trim();
    setState(() { _err = null; _botInfo = null; });
    if (token.isEmpty) {
      setState(() => _err = 'Token bot wajib diisi.');
      return;
    }
    setState(() => _loading = true);
    try {
      final res = await http
          .get(Uri.parse('https://api.telegram.org/bot$token/getMe'))
          .timeout(const Duration(seconds: 12));
      final data = jsonDecode(res.body);
      if (data['ok'] == true) {
        setState(() => _botInfo = data['result']);
      } else {
        setState(() => _err = 'Token tidak valid: ${data['description'] ?? 'unknown'}');
      }
    } catch (e) {
      setState(() => _err = 'Gagal konek: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('bot_token', _tokenCtrl.text.trim());
    await sp.setString('bot_program', _progCtrl.text.trim().isEmpty ? _defaultProgram() : _progCtrl.text.trim());
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => RunnerScreen(
        token: _tokenCtrl.text.trim(),
        program: sp.getString('bot_program')!,
      )),
    );
  }

  String _defaultProgram() {
    return '# Tulis logika bot di sini (handler command, dll).\n'
        '# Contoh: /start -> kirim sapaan\n';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Setup Bot', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Pertama kali jalanin bot? Masukkan token bot dari @BotFather.',
                style: TextStyle(color: Colors.white60, fontSize: 13)),
            const SizedBox(height: 22),
            const Text('BOT TOKEN', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white38, letterSpacing: 1)),
            const SizedBox(height: 8),
            TextField(
              controller: _tokenCtrl,
              obscureText: true,
              style: const TextStyle(fontFamily: 'monospace'),
              decoration: InputDecoration(
                hintText: '123456789:AAH...',
                filled: true,
                fillColor: Colors.black38,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: kAccent)),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading ? null : _validate,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kAccent, foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _loading
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                    : const Text('CEK BOT', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
            if (_err != null) ...[
              const SizedBox(height: 14),
              _banner(_err!, false),
            ],
            if (_botInfo != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: kAccent.withOpacity(0.25)),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 26, backgroundColor: kAccent.withOpacity(0.15),
                      child: const Icon(Icons.smart_toy, color: kAccent, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${_botInfo!['first_name'] ?? 'Bot'}',
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          const SizedBox(height: 2),
                          Text('@${_botInfo!['username'] ?? '-'}',
                              style: const TextStyle(color: kAccent, fontSize: 12, fontFamily: 'monospace')),
                          const SizedBox(height: 4),
                          const Text('Bot aktif & terdeteksi', style: TextStyle(color: Colors.greenAccent, fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const Text('PROGRAM BOT (opsional)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white38, letterSpacing: 1)),
              const SizedBox(height: 8),
              TextField(
                controller: _progCtrl,
                maxLines: 6,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                decoration: InputDecoration(
                  hintText: 'Paste program bot di sini...',
                  filled: true, fillColor: Colors.black38,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kAccent2, foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('MASUK KE RUNNER', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _banner(String msg, bool ok) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: (ok ? Colors.green : Colors.red).withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: (ok ? Colors.green : Colors.red).withOpacity(0.3)),
      ),
      child: Text(msg, style: TextStyle(color: ok ? Colors.greenAccent : Colors.redAccent, fontSize: 12.5)),
    );
  }
}

/* ================= RUNNER ================= */
class RunnerScreen extends StatefulWidget {
  final String token;
  final String program;
  const RunnerScreen({super.key, required this.token, required this.program});
  @override
  State<RunnerScreen> createState() => _RunnerScreenState();
}

class _RunnerScreenState extends State<RunnerScreen> {
  late TextEditingController _progCtrl;
  bool _running = false;
  bool _dirty = false;
  final List<String> _logs = [];

  @override
  void initState() {
    super.initState();
    _progCtrl = TextEditingController(text: widget.program);
    _progCtrl.addListener(() {
      if (!_dirty && _progCtrl.text != widget.program) setState(() => _dirty = true);
    });
    _log('info', 'Runner siap. Token tersimpan.');
  }

  void _log(String type, String msg) {
    final t = DateTime.now().toIso8601String().substring(11, 19);
    setState(() => _logs.add('[$t]|$type|$msg'));
  }

  Future<void> _toggle(bool v) async {
    if (v && _dirty) {
      _log('warn', 'Program berubah. Restart dulu sebelum RUN.');
      _snack('Restart dulu! Program sudah diubah.');
      return;
    }
    if (v) {
      setState(() => _running = true);
      _log('ok', 'Bot RUNNING. Menjalankan program...');
    } else {
      setState(() => _running = false);
      _log('info', 'Bot STOPPED.');
    }
  }

  Future<void> _restart() async {
    setState(() {
      _running = false;
      _dirty = false;
      widget.program == _progCtrl.text;
    });
    final sp = await SharedPreferences.getInstance();
    await sp.setString('bot_program', _progCtrl.text);
    _log('warn', 'Restart: program disimpan ulang.');
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => RunnerScreen(token: widget.token, program: _progCtrl.text)),
    );
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(m, style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: const Color(0xFF0F1420),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('KEPINBOTSTARTER', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        actions: [
          IconButton(
            onPressed: () async {
              final sp = await SharedPreferences.getInstance();
              await sp.clear();
              if (!mounted) return;
              Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const SetupScreen()));
            },
            icon: const Icon(Icons.logout, size: 20, color: Colors.white54),
          ),
        ],
      ),
      body: Column(
        children: [
          // Status + Toggle
          Container(
            margin: const EdgeInsets.fromLTRB(20, 8, 20, 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: Row(
              children: [
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _running ? Colors.greenAccent : Colors.white24,
                    boxShadow: _running
                        ? [BoxShadow(color: Colors.greenAccent.withOpacity(0.6), blurRadius: 10)]
                        : [],
                  ),
                ),
                const SizedBox(width: 10),
                Text(_running ? 'RUNNING' : 'STOPPED',
                    style: TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 12.5, letterSpacing: 0.5,
                      color: _running ? Colors.greenAccent : Colors.white38,
                    )),
                const Spacer(),
                GestureDetector(
                  onTap: () => _toggle(!_running),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: 58, height: 32,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(99),
                      gradient: _running
                          ? const LinearGradient(colors: [Color(0xFF10B981), Color(0xFF34D399)])
                          : null,
                      color: _running ? null : Colors.white.withOpacity(0.1),
                    ),
                    child: AnimatedAlign(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOutCubic,
                      alignment: _running ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.all(3),
                        width: 26, height: 26,
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                        child: Icon(
                          _running ? Icons.power_settings_new : Icons.power_settings_new,
                          size: 14, color: _running ? Colors.green : Colors.black45,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          if (_dirty)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.orange.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.warning_amber_rounded, size: 16, color: Colors.orangeAccent),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text('Program berubah. Klik RESTART sebelum RUN.',
                        style: TextStyle(fontSize: 11.5, color: Colors.orangeAccent, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),

          // Editor program
          Expanded(
            child: Container(
              margin: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              decoration: BoxDecoration(
                color: const Color(0xFF04070C),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06))),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.code, size: 14, color: kAccent3),
                        SizedBox(width: 7),
                        Text('program.bot', style: TextStyle(fontFamily: 'monospace', fontSize: 11.5, color: Colors.white60)),
                        Spacer(),
                        Text('EDITABLE', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: Colors.amber, letterSpacing: 0.6)),
                      ],
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _progCtrl,
                      maxLines: null,
                      expands: true,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5, height: 1.6, color: Colors.white70),
                      decoration: const InputDecoration(
                        hintText: 'Paste program bot di sini...',
                        hintStyle: TextStyle(color: Colors.white24),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.all(14),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Logs
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            height: 110,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF04070C),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: ListView(
              reverse: true,
              children: _logs.reversed.map((l) {
                final parts = l.split('|');
                Color c = Colors.white38;
                if (parts.length > 1) {
                  if (parts[1] == 'ok') c = Colors.greenAccent;
                  else if (parts[1] == 'warn') c = Colors.orangeAccent;
                  else if (parts[1] == 'err') c = Colors.redAccent;
                  else if (parts[1] == 'info') c = kAccent;
                }
                return Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    parts.length > 2 ? '${parts[0]} ${parts[2]}' : l,
                    style: TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: c),
                  ),
                );
              }).toList(),
            ),
          ),

          // Actions
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _restart,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('RESTART', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.orangeAccent,
                      side: BorderSide(color: Colors.orangeAccent.withOpacity(0.4)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: ElevatedButton.icon(
                    onPressed: _dirty ? null : () => _toggle(!_running),
                    icon: Icon(_running ? Icons.stop : Icons.play_arrow, size: 20),
                    label: Text(_running ? 'STOP BOT' : 'RUN BOT',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _running ? Colors.redAccent : const Color(0xFF10B981),
                      foregroundColor: Colors.black,
                      disabledBackgroundColor: Colors.white.withOpacity(0.06),
                      disabledForegroundColor: Colors.white30,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
