package com.kepin.bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
